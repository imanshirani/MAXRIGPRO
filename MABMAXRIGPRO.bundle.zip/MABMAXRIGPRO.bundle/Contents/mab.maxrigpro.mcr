macroScript MaxRigPro category:"MYARTSBOX" tooltip:"3Ds Max Rig Pro"
(
    filein "mab.maxrigpro.ms" 
)
